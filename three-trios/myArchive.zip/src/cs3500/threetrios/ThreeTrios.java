package cs3500.threetrios;

import cs3500.threetrios.controller.ConfigurationFileReader;
import cs3500.threetrios.controller.ThreeTriosGameController;
import cs3500.threetrios.model.Color;
import cs3500.threetrios.model.ThreeTriosGameModel;
import cs3500.threetrios.model.ThreeTriosGameModelObserver;
import cs3500.threetrios.model.ThreeTriosModel;
import cs3500.threetrios.players.HumanPlayer;
import cs3500.threetrios.players.MachinePlayer;
import cs3500.threetrios.players.Player;
import cs3500.threetrios.strategies.CornerStrategy;
import cs3500.threetrios.strategies.MaximizeFlipsStrategy;
import cs3500.threetrios.strategies.MiniMaxStrategy;
import cs3500.threetrios.strategies.MinimizeChanceOfBeingFlippedStrategy;
import cs3500.threetrios.strategies.ThreeTriosStrategy;
import cs3500.threetrios.view.ThreeTriosFrameGUI;

/**
 * Represents the main class for the Three Trios game.
 */
public final class ThreeTrios {
  /**
   * Main method for the Three Trios game.
   *
   * @param args command line arguments
   */
  public static void main(String[] args) {

    try {
      String player1Config = args[0].toUpperCase().trim();
      String player2Config = args[1].toUpperCase().trim();

      ThreeTriosModel model = new ThreeTriosGameModel(ConfigurationFileReader
              .createGridFromFile("gridClassExample.txt"),
              ConfigurationFileReader.createDeckFromFile("deckLarge.txt"));
      ThreeTriosFrameGUI view1 = new ThreeTriosFrameGUI(new ThreeTriosGameModelObserver(model));
      ThreeTriosFrameGUI view2 = new ThreeTriosFrameGUI(new ThreeTriosGameModelObserver(model));
      Player player1 = getPlayer(player1Config, model, Color.RED);
      Player player2 = getPlayer(player2Config, model, Color.BLUE);

      new ThreeTriosGameController(model, player1, view1, Color.RED);
      new ThreeTriosGameController(model, player2, view2, Color.BLUE);

      view1.setVisible(true);
      view2.setVisible(true);

      model.startGame();

    } catch (IllegalArgumentException | IndexOutOfBoundsException exception) {
      System.out.println("Invalid setup. Could not start program.");
    }
  }

  private static Player getPlayer(String type, ThreeTriosModel model, Color color) {
    if (type.equals("HUMAN")) {
      return new HumanPlayer();
    } else {
      ThreeTriosStrategy strategy = null;
      switch (type) {
        case "STRATEGY1":
          strategy = new MaximizeFlipsStrategy(null);
          break;
        case "STRATEGY2":
          strategy = new CornerStrategy(null);
          break;
        case "STRATEGY3":
          strategy = new MinimizeChanceOfBeingFlippedStrategy(null);
          break;
        case "STRATEGY4":
          strategy = new MiniMaxStrategy(new MaximizeFlipsStrategy(null),
                  new MaximizeFlipsStrategy(null));
          break;
        default:
          throw new IllegalArgumentException("Not a valid strategy");
      }
      return new MachinePlayer(model, strategy, color);
    }
  }
}