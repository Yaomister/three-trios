package cs3500.threetrios.model;

/**
 * Represents a card color in the game.
 * A color is either RED or BLUE.
 */
public enum Color {
  RED, BLUE
}
