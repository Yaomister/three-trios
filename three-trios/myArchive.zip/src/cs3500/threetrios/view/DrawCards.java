package cs3500.threetrios.view;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.geom.Path2D;

import cs3500.threetrios.model.Card;

/**
 * Represents the draw cards.
 */
public class DrawCards extends Path2D.Double {

  private int width;
  private int height;

  /**
   * Draws a rectangle with the given width and height.
   *
   * @param width  the width of the rectangle
   * @param height the height of the rectangle
   */
  public DrawCards(int width, int height) {
    this.width = width;
    this.height = height;
    moveTo(0, 0);
    lineTo(width, 0);
    lineTo(width, height);
    lineTo(0, height);
    closePath();
  }

  /**
   * Draws a card with the given width and height.
   *
   * @param g2d      the graphics
   * @param card     the card
   * @param fontSize the fontsize
   */
  public void drawCardNumbers(Graphics2D g2d, Card card,
                              int fontSize) {
    g2d.setColor(Color.BLACK);
    FontMetrics fm = g2d.getFontMetrics();

    // North
    String northText = card.getNorth().toString();
    int northX = (width - fm.stringWidth(northText)) / 2;
    int northY = fm.getAscent();
    g2d.drawString(northText, northX, northY);

    // East
    String eastText = card.getEast().toString();
    int eastX = width - fm.stringWidth(eastText) - (width / 4);
    int eastY = (height + fm.getAscent()) / 2;
    g2d.drawString(eastText, eastX, eastY);

    // South
    String southText = card.getSouth().toString();
    int southX = (width - fm.stringWidth(southText)) / 2;
    int southY = height - fm.getDescent();
    g2d.drawString(southText, southX, southY);

    // West
    String westText = card.getWest().toString();
    int westX = (width / 4);
    int westY = (height + fm.getAscent()) / 2;
    g2d.drawString(westText, westX, westY);
  }
}
