package cs3500.threetrios;

/**
 * Mock class for the ThreeTriosModel for the controller.
 */
public class MockThreeTriosModelForControllerActive extends MockThreeTriosModelForControllerOver {

  /**
   * Constructor for the MockThreeTriosModelForControllerActive class.
   *
   * @param log The StringBuilder to which logs will be appended.
   */
  public MockThreeTriosModelForControllerActive(StringBuilder log) {
    super(log);
  }

  @Override
  public boolean isGameOver() {
    log.append("isGameOver called\n");
    return false;
  }

}
