package cs3500.threetrios;

import java.util.List;

import cs3500.threetrios.model.Card;

/**
 * Mock class to test that there is only one row available to play.
 */
public class MockOnlyOneRowAvailableToPlay extends Mock {

  public MockOnlyOneRowAvailableToPlay(boolean[][] grid, List<Card> deck) {
    super(grid, deck);
  }

  @Override
  public boolean isPlayLegal(int row, int col) {
    // make top left corner unavailable
    return row == 2;
  }
}
