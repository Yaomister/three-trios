package cs3500.threetrios.strategies;

import org.junit.Test;

import java.util.List;

import cs3500.threetrios.model.Card;
import cs3500.threetrios.model.Color;

import static org.junit.Assert.assertEquals;

/**
 * Tests for the BreakTieStrategy class.
 */
public class TestBreakTieStrategy extends TestStrategy {

  @Test
  public void testStrategyCorrectlyChoosesTopMostMove() {
    List<Move> moves = this.strategy.chooseMoves(this.equalAmountFlipForAllPlaysModel,
            Color.RED, null);
    assertEquals(1, moves.size());
    Move move = moves.get(0);
    // Top left corner
    assertEquals(0, move.row);
    assertEquals(0, move.col);
    List<Card> hand = this.equalAmountFlipForAllPlaysModel.getPlayerHand(Color.RED);
    // Index zero in hand
    assertEquals(0, hand.indexOf(move.card));

  }

  @Test
  public void testStrategyBreaksTieByReturnsCellClosestToTopLeftWithTopLeftCornerUnavailable() {
    // It should value up-ness, over left-ness
    List<Move> moves = this.strategy.chooseMoves(this.lieLegalityOfLeftCorner,
            Color.RED, null);
    assertEquals(1, moves.size());
    Move move = moves.get(0);
    assertEquals(0, move.row);
    assertEquals(1, move.col);
    List<Card> hand = this.lieLegalityOfLeftCorner.getPlayerHand(Color.RED);
    assertEquals(0, hand.indexOf(move.card));
  }

  @Test
  public void testStrategyCorrectlyChoosesLeftMostMove() {
    // Should choose the leftmost out of that one row
    List<Move> moves = this.strategy.chooseMoves(this.onlyOneRowAvailableToPlay,
            Color.RED, null);
    Move bestMove = moves.get(0);
    assertEquals(2, bestMove.row);
    assertEquals(0, bestMove.col);
  }

  @Test
  public void testStrategyCorrectlyChoosesMoveWithCardHandIndexZero() {
    // Only one playable cell, so we're checking it chooses the correct card
    List<Move> moves = this.strategy.chooseMoves(this.oneByOneModel, Color.RED, null);
    Move bestMove = moves.get(0);
    List<Card> hand = this.oneByOneModel.getPlayerHand(Color.RED);
    assertEquals(0, hand.indexOf(bestMove.card));
  }

  @Override
  protected void createStrategy() {
    this.strategy = new BreakTieStrategy();
  }

}
