package cs3500.threetrios.strategies;

import org.junit.Test;

import java.util.List;

import cs3500.threetrios.model.Card;
import cs3500.threetrios.model.Color;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Tests for the CornerStrategy class.
 */
public class TestCornerStrategy extends TestStrategy {

  @Test
  public void testStrategySearchedAllPlayableLocations() {
    this.strategy.chooseMoves(this.confirmsSearchesModel, Color.RED, null);
    String output = mockOut.toString();
    // make sure each corner is checked
    assertTrue(output.contains("Inspected legality of playing at (0,0)"));
    assertTrue(output.contains("Inspected legality of playing at (2,0)"));
    assertTrue(output.contains("Inspected legality of playing at (0,2)"));
    assertTrue(output.contains("Inspected legality of playing at (2,2)"));
  }

  @Test
  public void testStrategyWorksWithFullPlaythrough() {

    // Make sure that that first four picks are the four corners
    List<Move> moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.RED, null);

    Move bestMove = moves.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(0, bestMove.col);
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(2, bestMove.col);
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.RED, null);
    bestMove = moves.get(0);
    assertEquals(2, bestMove.row);
    assertEquals(0, bestMove.col);
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(2, bestMove.row);
    assertEquals(2, bestMove.col);
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();
  }

  @Test
  public void testStrategyBreaksTieByReturnsCellClosestToTopLeftAndCardIndexZeroInHand() {
    List<Move> moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.RED, null);
    assertEquals(1, moves.size());
    Move move = moves.get(0);
    // Top left corner
    assertEquals(0, move.row);
    assertEquals(0, move.col);
    List<Card> hand = this.equalAmountFlipForAllPlaysModel.getPlayerHand(Color.RED);
    // Index zero in hand
    assertEquals(1, hand.indexOf(move.card));
  }

  @Test
  public void testStrategyReturnsCellClosestToTopLeftAndCardIndexZeroInHandWhenCornersAreFilled() {
    List<Move> moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.RED, null);

    Move bestMove = moves.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(0, bestMove.col);
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();
  }

  @Test
  public void testStrategyWorksChainingWithSelf() {
    ThreeTriosStrategy chainedWithSelf =
            new CornerStrategy(new CornerStrategy(null));
    List<Move> plainAnswer =
            this.strategy.chooseMoves(this.threeByThreeModel, Color.RED, null);
    List<Move> chainedAnswer =
            chainedWithSelf.chooseMoves(this.threeByThreeModel, Color.RED, null);
    // These two should produce the same answer
    assertEquals(chainedAnswer.size(), plainAnswer.size());
    assertArrayEquals(plainAnswer.toArray(), chainedAnswer.toArray());
  }

  @Test
  public void testStrategyWorksChainingWithMaximizingFlipsStrategy() {
    threeByThreeModel.playCard(2, 1, 0);
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    threeByThreeModel.playCard(0, 0, 2);
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    threeByThreeModel.playCard(1, 2, 1);
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    // Should pick the bottom right corner, because it is the only cell that
    // could flip 2 cards (playing to bottom left and top right could only flip 1 card each)
    ThreeTriosStrategy chainedWithMaximize =
            new CornerStrategy(new MaximizeFlipsStrategy(null));
    List<Move> response =
            chainedWithMaximize.chooseMoves(this.threeByThreeModel, Color.BLUE, null);
    Move bestMove = response.get(0);
    assertEquals(2, bestMove.row);
    assertEquals(0, bestMove.col);
  }

  @Test
  public void testStrategyWorksChainingWithMinimizingOpponentsFlipsStrategy() {
    // Should pick top left corner
    ThreeTriosStrategy chainedWithMinimize =
            new CornerStrategy(new MinimizeChanceOfBeingFlippedStrategy(null));
    List<Move> response = chainedWithMinimize
            .chooseMoves(this.threeByThreeModel, Color.BLUE, null);
    Move bestMove = response.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(0, bestMove.col);


    threeByThreeModel.playCard(0, 1, 3);
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    threeByThreeModel.playCard(2, 2, 2);
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    threeByThreeModel.playCard(1, 2, 1);
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    // Should pick top right corner because it is surrounded on all four sides
    response = chainedWithMinimize
            .chooseMoves(this.threeByThreeModel, Color.BLUE, null);
    bestMove = response.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(2, bestMove.col);
  }

  @Override
  protected void createStrategy() {
    this.strategy = new CornerStrategy(null);
  }


}
