package cs3500.threetrios.strategies;

import org.junit.Test;

import java.util.List;

import cs3500.threetrios.model.Card;
import cs3500.threetrios.model.Color;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;


/**
 * Tests for the MinimizeChanceOfBeingFlippedStrategy class.
 */
public class TestMinimizeChanceOfBeingFlippedStrategy extends TestStrategy {

  @Test
  public void testStrategyWorksBySelectingFullySurroundedSpot() {

    this.threeByThreeModel.playCard(0, 1, 0);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();

    this.threeByThreeModel.playCard(1, 0, 0);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();

    this.threeByThreeModel.playCard(1, 2, 0);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();

    Move bestMove = this.strategy.chooseMoves(this.threeByThreeModel,
            Color.RED, null).get(0);
    assertEquals(0, bestMove.row);
    assertEquals(0, bestMove.col);
  }

  @Test
  public void testStrategyWorksWithFullPlaythrough() {
    // Checking that it makes the correct predictions that minimizes
    // the amount of flips an opponent can make in a real game


    List<Move> moves = this.strategy.chooseMoves(this.largeModel, Color.RED,
            null);
    // Top left corner since they all flip equal amounts of cards
    Move bestMove = moves.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(0, bestMove.col);
    assertEquals(7, largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.battle();
    largeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.largeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(2, bestMove.col);
    assertEquals(2, largeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    largeModel.battle();
    largeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.largeModel, Color.RED, null);
    bestMove = moves.get(0);
    assertEquals(1, bestMove.row);
    assertEquals(1, bestMove.col);
    assertEquals(1, largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.battle();
    largeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.largeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(1, bestMove.row);
    assertEquals(0, bestMove.col);
    assertEquals(7, largeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    largeModel.battle();
    largeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.largeModel, Color.RED, null);
    bestMove = moves.get(0);
    assertEquals(1, bestMove.row);
    assertEquals(3, bestMove.col);
    assertEquals(4, largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.battle();
    largeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.largeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(3, bestMove.row);
    assertEquals(1, bestMove.col);
    assertEquals(2, largeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    largeModel.battle();
    largeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.largeModel, Color.RED, null);
    bestMove = moves.get(0);
    assertEquals(1, bestMove.row);
    assertEquals(2, bestMove.col);
    assertEquals(3, largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.battle();
    largeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.largeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(3, bestMove.row);
    assertEquals(3, bestMove.col);
    assertEquals(3, largeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    largeModel.battle();
    largeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.largeModel, Color.RED, null);
    bestMove = moves.get(0);
    assertEquals(2, bestMove.row);
    assertEquals(0, bestMove.col);
    assertEquals(3, largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.battle();
    largeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.largeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(2, bestMove.row);
    assertEquals(2, bestMove.col);
    assertEquals(4, largeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    largeModel.battle();
    largeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.largeModel, Color.RED, null);
    bestMove = moves.get(0);
    assertEquals(3, bestMove.row);
    assertEquals(0, bestMove.col);
    assertEquals(1, largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.battle();
    largeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.largeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(4, bestMove.col);
    assertEquals(3, largeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    largeModel.battle();
    largeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.largeModel, Color.RED, null);
    bestMove = moves.get(0);
    assertEquals(1, bestMove.row);
    assertEquals(4, bestMove.col);
    assertEquals(3, largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.battle();
    largeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.largeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(2, bestMove.row);
    assertEquals(4, bestMove.col);
    assertEquals(3, largeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    largeModel.battle();
    largeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.largeModel, Color.RED, null);
    bestMove = moves.get(0);
    assertEquals(3, bestMove.row);
    assertEquals(2, bestMove.col);
    assertEquals(0, largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.battle();
    largeModel.nextTurn();


    moves = this.strategy.chooseMoves(this.largeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(4, bestMove.row);
    assertEquals(0, bestMove.col);
    assertEquals(1, largeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    largeModel.battle();
    largeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.largeModel, Color.RED, null);
    bestMove = moves.get(0);
    assertEquals(4, bestMove.row);
    assertEquals(2, bestMove.col);
    assertEquals(0, largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.battle();
    largeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.largeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(3, bestMove.row);
    assertEquals(4, bestMove.col);
    assertEquals(0, largeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    largeModel.battle();
    largeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.largeModel, Color.RED, null);
    bestMove = moves.get(0);
    assertEquals(4, bestMove.row);
    assertEquals(4, bestMove.col);
    assertEquals(0, largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    largeModel.playCard(bestMove.row, bestMove.col,
            largeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));

  }

  @Test
  public void testStrategyBreaksTieByReturningCellClosestToTopLeftAndHandIndexClosestToZero() {
    List<Move> moves = this.strategy
            .chooseMoves(this.threeByThreeModel, Color.RED, null);
    assertEquals(1, moves.size());
    Move move = moves.get(0);
    // Top left corner
    assertEquals(0, move.row);
    assertEquals(0, move.col);
    List<Card> hand = this.equalAmountFlipForAllPlaysModel.getPlayerHand(Color.RED);
    // Index closest to zero in hand
    assertEquals(1, hand.indexOf(move.card));
  }

  @Test
  public void testStrategyWorksChainingWithSelf() {
    ThreeTriosStrategy chainedWithSelf =
            new MinimizeChanceOfBeingFlippedStrategy(
                    new MinimizeChanceOfBeingFlippedStrategy(null));
    List<Move> plainAnswer = this.strategy.chooseMoves(this.threeByThreeModel,
            Color.RED, null);
    List<Move> chainedAnswer = chainedWithSelf.chooseMoves(this.threeByThreeModel,
            Color.RED, null);
    // These two should produce the same answer
    assertEquals(chainedAnswer.size(), plainAnswer.size());
    assertArrayEquals(plainAnswer.toArray(), chainedAnswer.toArray());
  }

  @Test
  public void testStrategyWorksChainingWithCornerStrategy() {
    ThreeTriosStrategy chainedWithCorner =
            new MinimizeChanceOfBeingFlippedStrategy(new CornerStrategy(null));
    List<Move> response = chainedWithCorner.chooseMoves(this.threeByThreeModel, Color.RED,
            null);
    Move bestMove = response.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(0, bestMove.col);

    // Given that the top left corner was fill, it would choose the top right corner
    response = chainedWithCorner.chooseMoves(this.lieLegalityOfLeftCorner, Color.RED,
            null);
    bestMove = response.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(2, bestMove.col);


    this.threeByThreeModel.playCard(0, 1, 3);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();

    this.threeByThreeModel.playCard(2, 2, 2);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();

    this.threeByThreeModel.playCard(1, 2, 1);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();


    // Should pick top right corner, because it is surrounded by two other cards, thus placing here
    // would be the hardest to flip AND is in a corner
    response = chainedWithCorner.chooseMoves(this.threeByThreeModel, Color.BLUE, null);
    bestMove = response.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(2, bestMove.col);

  }

  @Test
  public void testStrategyWorksChainingWithMaximizeFlipsStrategy() {
    this.threeByThreeModel.playCard(0, 1, 0);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();

    this.threeByThreeModel.playCard(1, 0, 1);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();

    this.threeByThreeModel.playCard(1, 2, 1);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();

    ThreeTriosStrategy chainedWithMaximize = new
            MinimizeChanceOfBeingFlippedStrategy(new MaximizeFlipsStrategy(null));
    Move bestMove = chainedWithMaximize.chooseMoves(this.threeByThreeModel,
            Color.BLUE, null).get(0);

    // It should suggest playing to the center instead of the top left or right corners.
    // Playing to the corners would flip 1 red card, whereas playing to the center will
    // flip the 2 red cards.
    assertEquals(1, bestMove.row);
    assertEquals(1, bestMove.col);

  }

  @Override
  protected void createStrategy() {
    this.strategy = new MinimizeChanceOfBeingFlippedStrategy(null);
  }
}
