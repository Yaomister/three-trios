package cs3500.threetrios.strategies;

import org.junit.Before;
import org.junit.Test;

import cs3500.threetrios.MockCannotPlayAnywhere;
import cs3500.threetrios.MockConfirmsSearches;
import cs3500.threetrios.MockEqualAmountFlipForAllPlays;
import cs3500.threetrios.MockGameOver;
import cs3500.threetrios.MockLieLegalityOfLeftCorner;
import cs3500.threetrios.MockOnlyOneRowAvailableToPlay;
import cs3500.threetrios.MockPredeterminedBestPlay;
import cs3500.threetrios.controller.ConfigurationFileReader;
import cs3500.threetrios.model.Color;
import cs3500.threetrios.model.ThreeTriosGameModel;
import cs3500.threetrios.model.ThreeTriosModel;


/**
 * Tests for the all classes implementing the ThreeTriosStrategy. (shared tests between all
 * strategies).
 */
public abstract class TestStrategy {

  protected ThreeTriosModel largeModel;
  protected ThreeTriosModel threeByThreeModel;
  protected ThreeTriosModel oneByOneModel;
  protected ThreeTriosModel confirmsSearchesModel;
  protected ThreeTriosModel lieLegalityOfLeftCorner;
  protected ThreeTriosModel onlyOneRowAvailableToPlay;
  protected ThreeTriosModel predeterminedBestPlayModel;
  protected ThreeTriosModel equalAmountFlipForAllPlaysModel;
  protected ThreeTriosModel gameOverModel;
  protected ThreeTriosModel cannotPlayAnywhereModel;
  protected StringBuilder mockOut;
  protected ThreeTriosStrategy strategy;

  protected abstract void createStrategy();

  @Before
  public void setup() {
    this.mockOut = new StringBuilder();

    this.threeByThreeModel = new ThreeTriosGameModel(ConfigurationFileReader
            .createGridFromFile("gridThreeByThreeNoHoles.txt"),
            ConfigurationFileReader.createDeckFromFile("deckLarge.txt"));
    this.threeByThreeModel.startGame();

    this.confirmsSearchesModel = new MockConfirmsSearches(ConfigurationFileReader
            .createGridFromFile("gridThreeByThreeNoHoles.txt"),
            ConfigurationFileReader.createDeckFromFile("deckLarge.txt"), mockOut);
    this.confirmsSearchesModel.startGame();

    this.lieLegalityOfLeftCorner = new MockLieLegalityOfLeftCorner(ConfigurationFileReader
            .createGridFromFile("gridThreeByThreeNoHoles.txt"),
            ConfigurationFileReader.createDeckFromFile("deckLarge.txt"));
    this.lieLegalityOfLeftCorner.startGame();

    this.predeterminedBestPlayModel = new MockPredeterminedBestPlay(ConfigurationFileReader
            .createGridFromFile("gridThreeByThreeNoHoles.txt"),
            ConfigurationFileReader.createDeckFromFile("deckLarge.txt"));
    this.predeterminedBestPlayModel.startGame();

    this.equalAmountFlipForAllPlaysModel
            = new MockEqualAmountFlipForAllPlays(ConfigurationFileReader
            .createGridFromFile("gridThreeByThreeNoHoles.txt"),
            ConfigurationFileReader.createDeckFromFile("deckLarge.txt"));
    this.equalAmountFlipForAllPlaysModel.startGame();

    this.onlyOneRowAvailableToPlay = new MockOnlyOneRowAvailableToPlay(ConfigurationFileReader
            .createGridFromFile("gridThreeByThreeNoHoles.txt"),
            ConfigurationFileReader.createDeckFromFile("deckLarge.txt"));
    this.onlyOneRowAvailableToPlay.startGame();

    this.oneByOneModel = new ThreeTriosGameModel(ConfigurationFileReader
            .createGridFromFile("gridOneByOne.txt"),
            ConfigurationFileReader.createDeckFromFile("deckLarge.txt"));
    this.oneByOneModel.startGame();

    this.largeModel = new ThreeTriosGameModel(ConfigurationFileReader
            .createGridFromFile("gridWithPathToAllCells.txt"),
            ConfigurationFileReader.createDeckFromFile("deckLarge.txt"));
    this.largeModel.startGame();

    this.gameOverModel = new MockGameOver(ConfigurationFileReader
            .createGridFromFile("gridWithPathToAllCells.txt"),
            ConfigurationFileReader.createDeckFromFile("deckLarge.txt"));

    this.cannotPlayAnywhereModel = new MockCannotPlayAnywhere(ConfigurationFileReader
            .createGridFromFile("gridWithPathToAllCells.txt"),
            ConfigurationFileReader.createDeckFromFile("deckLarge.txt"));
    this.cannotPlayAnywhereModel.startGame();

    this.createStrategy();
  }

  @Test(expected = IllegalArgumentException.class)
  public void StrategyThrowsIAEWhenModelIsNull() {
    strategy.chooseMoves(null, Color.RED, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void StrategyThrowsIAEWhenPlayerColorIsNull() {
    strategy.chooseMoves(threeByThreeModel, null, null);
  }

  @Test(expected = IllegalStateException.class)
  public void StrategyThrowsISEWhenModelIsGameOver() {
    strategy.chooseMoves(gameOverModel, Color.RED, null);
  }

  @Test(expected = IllegalStateException.class)
  public void StrategyThrowsISEWhenCannotPlayToAnywhere() {
    strategy.chooseMoves(cannotPlayAnywhereModel, Color.RED, null);
  }

  protected int amountOfLinesContaining(String output, String phrase) {
    int amount = 0;
    for (String line : output.split("\n")) {
      if (line.contains(phrase)) {
        amount++;
      }
    }
    return amount;
  }

}
