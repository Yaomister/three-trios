package cs3500.threetrios.strategies;

import org.junit.Test;

import java.util.List;

import cs3500.threetrios.model.Card;
import cs3500.threetrios.model.Color;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;


/**
 * Tests for the MaximizeFlipsStrategy class.
 */
public class TestMaximizeFlipsStrategy extends TestStrategy {

  @Test
  public void testStrategySearchedAllPlayableLocations() {
    this.strategy.chooseMoves(this.confirmsSearchesModel, Color.RED, null);
    String output = mockOut.toString();
    //  Should be five, as we check for each of the five cards in the hand
    for (int row = 0; row < 3; row++) {
      for (int col = 0; col < 3; col++) {
        assertEquals(5, amountOfLinesContaining(output,
                "Inspected legality of playing at (" + row + "," + col + ")"));
      }
    }
    // Should have calculated the damage done 9 times for each card
    assertEquals(9, amountOfLinesContaining(output,
            "Calculated damage for placing 8-Bit"));
    assertEquals(9, amountOfLinesContaining(output,
            "Calculated damage for placing Amber"));
    assertEquals(9, amountOfLinesContaining(output,
            "Calculated damage for placing Angelo"));
    assertEquals(9, amountOfLinesContaining(output,
            "Calculated damage for placing Ash"));
    assertEquals(9, amountOfLinesContaining(output,
            "Calculated damage for placing Barley"));
  }


  @Test
  public void testStrategyWorksWithFullPlaythrough() {
    // Checking that it makes the correct predictions
    // that maximizes the amount of flips in a real game

    List<Move> moves = this.strategy.chooseMoves(this.threeByThreeModel,
            Color.RED, null);
    // Top left corner since they all flip equal amounts of cards
    Move bestMove = moves.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(0, bestMove.col);
    assertEquals(0, threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(1, bestMove.col);
    assertEquals(3, threeByThreeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.RED, null);
    bestMove = moves.get(0);
    assertEquals(1, bestMove.row);
    assertEquals(1, bestMove.col);
    assertEquals(0, threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(1, bestMove.row);
    assertEquals(0, bestMove.col);
    assertEquals(0, threeByThreeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();


    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.RED, null);
    bestMove = moves.get(0);
    assertEquals(2, bestMove.row);
    assertEquals(0, bestMove.col);
    assertEquals(0, threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(1, bestMove.row);
    assertEquals(2, bestMove.col);
    assertEquals(2, threeByThreeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.RED, null);
    bestMove = moves.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(2, bestMove.col);
    assertEquals(0, threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(2, bestMove.row);
    assertEquals(1, bestMove.col);
    assertEquals(0, threeByThreeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.RED, null);
    bestMove = moves.get(0);
    assertEquals(2, bestMove.row);
    assertEquals(2, bestMove.col);
    assertEquals(0, threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
  }

  @Test
  public void testStrategyReturnsPredeterminedBestMove() {
    // Mock predetermines that (1, 1) is the location that flips the most cards
    List<Move> moves = this.strategy.chooseMoves(this.predeterminedBestPlayModel,
            Color.RED, null);
    assertEquals(1, moves.size());
    Move move = moves.get(0);
    assertEquals(1, move.row);
    assertEquals(1, move.col);
    List<Card> hand = this.predeterminedBestPlayModel.getPlayerHand(Color.RED);
    assertEquals(0, hand.indexOf(move.card));
  }


  @Test
  public void testStrategyBreaksTieByReturningCellClosestToTopLeftAndHandIndexClosestToZero() {
    List<Move> moves = this.strategy.chooseMoves(this.equalAmountFlipForAllPlaysModel,
            Color.RED, null);
    assertEquals(1, moves.size());
    Move move = moves.get(0);
    // Top left corner
    assertEquals(0, move.row);
    assertEquals(0, move.col);
    List<Card> hand = this.equalAmountFlipForAllPlaysModel.getPlayerHand(Color.RED);
    // Index zero in hand
    assertEquals(0, hand.indexOf(move.card));

  }

  @Test
  public void testStrategyWorksChainingWithSelf() {
    ThreeTriosStrategy chainedWithSelf =
            new MaximizeFlipsStrategy(new MaximizeFlipsStrategy(null));
    List<Move> plainAnswer =
            this.strategy.chooseMoves(this.threeByThreeModel, Color.RED, null);
    List<Move> chainedAnswer =
            chainedWithSelf.chooseMoves(this.threeByThreeModel, Color.RED, null);
    // These two should produce the same answer
    assertEquals(chainedAnswer.size(), plainAnswer.size());
    assertArrayEquals(plainAnswer.toArray(), chainedAnswer.toArray());
  }

  @Test
  public void testStrategyWorksChainingWithCornerStrategy() {
    ThreeTriosStrategy chainedWithCorner =
            new MaximizeFlipsStrategy(new CornerStrategy(null));
    List<Move> response =
            chainedWithCorner.chooseMoves(this.threeByThreeModel, Color.RED, null);
    Move bestMove = response.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(0, bestMove.col);
    // Given that the top left corner was fill, it would choose the top right corner
    response = chainedWithCorner
            .chooseMoves(this.lieLegalityOfLeftCorner, Color.RED, null);
    bestMove = response.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(2, bestMove.col);

    this.threeByThreeModel.playCard(0, 0, 0);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();
    // Given that there is a card on the board, it would first look for
    // the spot that flips the most cards. Then the corner strategy will
    // look at those moves and fail to find a corner, which the tiebreaker
    // will simply return the top-most left-most cell to play.

    response = chainedWithCorner.chooseMoves(this.threeByThreeModel, Color.RED, null);
    bestMove = response.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(1, bestMove.col);

    this.threeByThreeModel.playCard(0, 1, 1);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();

    this.threeByThreeModel.playCard(2, 2, 2);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();

    this.threeByThreeModel.playCard(1, 2, 1);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();

    // Should pick top right corner, because it is surrounded by two blue cards, thus placing here
    // would flip the most amount of cards (2) and be the hardest to flip
    response = chainedWithCorner.chooseMoves(this.threeByThreeModel, Color.RED, null);
    bestMove = response.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(2, bestMove.col);


  }

  @Test
  public void testStrategyWorksChainingWithMinimizingOpponentsFlipsStrategy() {
    ThreeTriosStrategy chainedWithMinimize =
            new MaximizeFlipsStrategy(new MinimizeChanceOfBeingFlippedStrategy(null));
    List<Move> response = chainedWithMinimize
            .chooseMoves(this.threeByThreeModel, Color.RED, null);
    Move bestMove = response.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(0, bestMove.col);

    this.threeByThreeModel.playCard(0, 0, 0);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();

    // Given the top left corner is taken by a red card, blue should then take
    // the cell under it, because that is the next hardest spot to flip AND
    // where you can flip the most cards (ie the only card on the board)
    response = chainedWithMinimize.chooseMoves(this.threeByThreeModel, Color.BLUE, null);
    bestMove = response.get(0);
    assertEquals(1, bestMove.row);
    assertEquals(0, bestMove.col);
  }

  @Override
  protected void createStrategy() {
    this.strategy = new MaximizeFlipsStrategy(null);
  }

}
