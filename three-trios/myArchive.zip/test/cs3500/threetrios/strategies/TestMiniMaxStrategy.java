package cs3500.threetrios.strategies;

import org.junit.Test;

import java.util.List;

import cs3500.threetrios.model.Card;
import cs3500.threetrios.model.Color;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

/**
 * Tests for the MiniMaxStrategy class.
 */
public class TestMiniMaxStrategy extends TestStrategy {

  @Override
  protected void createStrategy() {
    this.strategy = new MiniMaxStrategy(null,
            new MaximizeFlipsStrategy(null));
  }

  @Test
  public void testStrategyWorksWhenOpponentIsUsingMaximizingFlipsStrategy() {

    threeByThreeModel.playCard(0, 0, 0);
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    threeByThreeModel.playCard(0, 2, 0);
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    ThreeTriosStrategy opponentIsMaximizingFlipsStrategy =
            new MiniMaxStrategy(null, new MaximizeFlipsStrategy(null));
    List<Move> moves = opponentIsMaximizingFlipsStrategy
            .chooseMoves(this.threeByThreeModel, Color.RED, null);
    assertEquals(1, moves.size());
    Move move = moves.get(0);
    assertEquals(0, move.row);
    assertEquals(1, move.col);
    List<Card> hand = this.threeByThreeModel.getPlayerHand(Color.RED);
    assertEquals(0, hand.indexOf(move.card));
  }

  @Test
  public void testStrategyWorksWhenOpponentIsUsingCornerFlipsStrategy() {

    threeByThreeModel.playCard(0, 0, 0);
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    threeByThreeModel.playCard(2, 0, 0);
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    threeByThreeModel.playCard(2, 2, 0);
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    ThreeTriosStrategy opponentIsCornerStrategy =
            new MiniMaxStrategy(null, new CornerStrategy(null));
    List<Move> moves = opponentIsCornerStrategy
            .chooseMoves(this.threeByThreeModel, Color.BLUE, null);
    assertEquals(1, moves.size());
    Move move = moves.get(0);
    assertEquals(0, move.row);
    assertEquals(1, move.col);
  }

  @Test
  public void testStrategyWorksWhenOpponentIsUsingMinimizeChanceOfBeingFlippedStrategy() {

    threeByThreeModel.playCard(0, 1, 0);
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    threeByThreeModel.playCard(2, 2, 0);
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    threeByThreeModel.playCard(1, 0, 0);
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    ThreeTriosStrategy opponentIsMinimizeChanceOfBeingFlippedStrategy
            = new MiniMaxStrategy(null, new MinimizeChanceOfBeingFlippedStrategy(null));
    List<Move> moves = opponentIsMinimizeChanceOfBeingFlippedStrategy
            .chooseMoves(this.threeByThreeModel, Color.BLUE, null);
    assertEquals(1, moves.size());
    Move move = moves.get(0);
    assertEquals(0, move.row);
    assertEquals(0, move.col);
    // Since the opponent is picking the location that would minimize the
    // chance of them being flipped, playing to the corner (0, 0)
    // would only leave them with positions to play that minimize their score.
  }

  @Test
  public void testStrategyWorksWithFullPlaythrough() {

    List<Move> moves = this.strategy.chooseMoves(this.threeByThreeModel,
            Color.RED, null);

    Move bestMove = moves.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(0, bestMove.col);
    assertEquals(0, threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(1, bestMove.col);
    assertEquals(0, threeByThreeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.RED, null);
    bestMove = moves.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(2, bestMove.col);
    assertEquals(0, threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(1, bestMove.row);
    assertEquals(0, bestMove.col);
    assertEquals(0, threeByThreeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();


    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.RED, null);
    bestMove = moves.get(0);
    assertEquals(1, bestMove.row);
    assertEquals(1, bestMove.col);
    assertEquals(0, threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(1, bestMove.row);
    assertEquals(2, bestMove.col);
    assertEquals(0, threeByThreeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.RED, null);
    bestMove = moves.get(0);
    assertEquals(2, bestMove.row);
    assertEquals(0, bestMove.col);
    assertEquals(0, threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.BLUE, null);
    bestMove = moves.get(0);
    assertEquals(2, bestMove.row);
    assertEquals(1, bestMove.col);
    assertEquals(0, threeByThreeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.BLUE).indexOf(bestMove.card));
    threeByThreeModel.battle();
    threeByThreeModel.nextTurn();

    moves = this.strategy.chooseMoves(this.threeByThreeModel, Color.RED, null);
    bestMove = moves.get(0);
    assertEquals(2, bestMove.row);
    assertEquals(2, bestMove.col);
    assertEquals(0, threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
    threeByThreeModel.playCard(bestMove.row, bestMove.col,
            threeByThreeModel.getPlayerHand(Color.RED).indexOf(bestMove.card));
  }

  @Test
  public void testStrategyWorksChainingWithSelf() {
    ThreeTriosStrategy chainedWithSelf = new MiniMaxStrategy(
            new MiniMaxStrategy(null, new MaximizeFlipsStrategy(null)),
            new MaximizeFlipsStrategy(null));
    List<Move> plainAnswer = this.strategy.chooseMoves(this.threeByThreeModel,
            Color.RED, null);
    List<Move> chainedAnswer = chainedWithSelf.chooseMoves(this.threeByThreeModel,
            Color.RED, null);
    // These two should produce the same answer
    assertEquals(chainedAnswer.size(), plainAnswer.size());
    assertArrayEquals(plainAnswer.toArray(), chainedAnswer.toArray());
  }

  @Test
  public void testStrategyWorksChainingWithCornerStrategy() {
    ThreeTriosStrategy chainedWithCorner = new MiniMaxStrategy(
            new CornerStrategy(null), new MaximizeFlipsStrategy(null));
    List<Move> response = chainedWithCorner.chooseMoves(this.threeByThreeModel,
            Color.RED, null);
    Move bestMove = response.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(0, bestMove.col);
    // Given that the top left corner was fill, it would choose the top right corner
    response = chainedWithCorner.chooseMoves(this.lieLegalityOfLeftCorner,
            Color.RED, null);
    bestMove = response.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(1, bestMove.col);

    this.threeByThreeModel.playCard(0, 0, 2);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();


    response = chainedWithCorner.chooseMoves(this.threeByThreeModel, Color.RED, null);
    bestMove = response.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(1, bestMove.col);

    this.threeByThreeModel.playCard(0, 1, 1);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();

    this.threeByThreeModel.playCard(2, 2, 0);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();


    response = chainedWithCorner.chooseMoves(this.threeByThreeModel, Color.RED, null);
    bestMove = response.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(2, bestMove.col);
  }

  @Test
  public void testStrategyWorksChainingWithMinimizingOpponentsFlipsStrategy() {
    ThreeTriosStrategy chainedWithMinimize =
            new MiniMaxStrategy(new MinimizeChanceOfBeingFlippedStrategy(null),
                    new MaximizeFlipsStrategy(null));
    List<Move> response = chainedWithMinimize.chooseMoves(this.threeByThreeModel,
            Color.RED, null);
    Move bestMove = response.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(0, bestMove.col);

    this.threeByThreeModel.playCard(0, 0, 0);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();

    response = chainedWithMinimize.chooseMoves(this.threeByThreeModel, Color.BLUE, null);
    bestMove = response.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(1, bestMove.col);
  }


  @Test
  public void testStrategyWorksChainingWithMaximizingFlipsStrategy() {
    ThreeTriosStrategy chainedWithMaximize =
            new MiniMaxStrategy(new MaximizeFlipsStrategy(null),
                    new MaximizeFlipsStrategy(null));
    List<Move> response = chainedWithMaximize.chooseMoves(this.threeByThreeModel,
            Color.RED, null);
    Move bestMove = response.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(0, bestMove.col);

    this.threeByThreeModel.playCard(2, 1, 0);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();

    this.threeByThreeModel.playCard(0, 0, 0);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();

    this.threeByThreeModel.playCard(1, 2, 0);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();

    this.threeByThreeModel.playCard(0, 1, 0);
    this.threeByThreeModel.battle();
    this.threeByThreeModel.nextTurn();

    response = chainedWithMaximize.chooseMoves(this.threeByThreeModel,
            Color.RED, null);
    bestMove = response.get(0);
    assertEquals(0, bestMove.row);
    assertEquals(2, bestMove.col);
  }


}
