package cs3500.threetrios.view;

import org.junit.Assert;
import org.junit.Test;

import cs3500.threetrios.controller.ConfigurationFileReader;
import cs3500.threetrios.model.ThreeTriosGameModel;

/**
 * Test cases for the ThreeTriosTextView.
 * These tests ensure the output for a given input of grid and deck path
 * is correct and formatted as expected.
 */
public class TestThreeTriosTextView {

  private ThreeTriosGameModel model;
  private ThreeTriosTextView view;


  @Test
  public void testNoHoleLargeCard() {
    model = new ThreeTriosGameModel(ConfigurationFileReader
            .createGridFromFile("gridWithNoHoles.txt"),
            ConfigurationFileReader.createDeckFromFile("deckMedium.txt"));
    view = new ThreeTriosTextView(model);
    model.startGame();

    String rendered = view.render();
    Assert.assertTrue(rendered.contains("Player: RED"));

    String expectedOutput =
            "Player: RED\n"
                    + "_ _ _\n"
                    + "_ _ _\n"
                    + "_ _ _\n"
                    + "Hand:\n"
                    + "MortisTheClarinetSorcerer 2 8 1 7\n"
                    + "EmzTheDJMaster 5 6 1 6\n"
                    + "MegTheBattleBeetle 3 7 4 2\n"
                    + "SproutTheGardener A 5 2 8\n"
                    + "StuTheRockstar 9 8 1 4\n";

    Assert.assertEquals(expectedOutput, rendered);
  }

  @Test
  public void testInitialGameState() {
    model = new ThreeTriosGameModel(ConfigurationFileReader
            .createGridFromFile("gridWithNoHoles.txt"),
            ConfigurationFileReader.createDeckFromFile("deckMedium.txt"));
    view = new ThreeTriosTextView(model);
    model.startGame();

    String rendered = view.render();
    Assert.assertTrue(rendered.contains("Player: RED"));

    String expectedOutput =
            "Player: RED\n"
                    + "_ _ _\n"
                    + "_ _ _\n"
                    + "_ _ _\n"
                    + "Hand:\n"
                    + "MortisTheClarinetSorcerer 2 8 1 7\n"
                    + "EmzTheDJMaster 5 6 1 6\n"
                    + "MegTheBattleBeetle 3 7 4 2\n"
                    + "SproutTheGardener A 5 2 8\n"
                    + "StuTheRockstar 9 8 1 4\n";

    Assert.assertEquals(expectedOutput, rendered);
  }

  @Test
  public void testLargeCardDeck() {
    model = new ThreeTriosGameModel(ConfigurationFileReader
            .createGridFromFile("gridWithPathToAllCells.txt"),
            ConfigurationFileReader.createDeckFromFile("deckLarge.txt"));
    view = new ThreeTriosTextView(model);
    model.startGame();
    String rendered = view.render();

    String expectedOutput =
            "Player: RED\n"
                    + "_   _   _\n"
                    + "_ _ _ _ _\n"
                    + "_   _   _\n"
                    + "_ _ _ _ _\n"
                    + "_   _   _\n"
                    + "Hand:\n"
                    + "8-Bit 5 3 2 9\n"
                    + "Amber 6 2 9 3\n"
                    + "Angelo 9 7 1 6\n"
                    + "Ash 4 3 6 9\n"
                    + "Barley 4 6 9 2\n"
                    + "Bea A 5 8 2\n"
                    + "Belle 7 3 9 1\n"
                    + "Berry 6 4 3 2\n"
                    + "Bibi 9 A 1 8\n"
                    + "Bo 3 1 A 6\n";

    Assert.assertEquals(expectedOutput, rendered);
  }

  @Test
  public void testLargeCardDeckFilePath() {
    model = new ThreeTriosGameModel(ConfigurationFileReader
            .createGridFromFile("gridWithPathToAllCells.txt"),
            ConfigurationFileReader.createDeckFromFile("deckLarge.txt"));
    view = new ThreeTriosTextView(model);
    model.startGame();

    String rendered = view.render();

    String expectedOutput =
            "Player: RED\n"
                    + "_   _   _\n"
                    + "_ _ _ _ _\n"
                    + "_   _   _\n"
                    + "_ _ _ _ _\n"
                    + "_   _   _\n"
                    + "Hand:\n"
                    + "8-Bit 5 3 2 9\n"
                    + "Amber 6 2 9 3\n"
                    + "Angelo 9 7 1 6\n"
                    + "Ash 4 3 6 9\n"
                    + "Barley 4 6 9 2\n"
                    + "Bea A 5 8 2\n"
                    + "Belle 7 3 9 1\n"
                    + "Berry 6 4 3 2\n"
                    + "Bibi 9 A 1 8\n"
                    + "Bo 3 1 A 6\n";

    Assert.assertEquals(expectedOutput, rendered);
  }

}


