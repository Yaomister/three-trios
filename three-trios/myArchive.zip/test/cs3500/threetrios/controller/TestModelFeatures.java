package cs3500.threetrios.controller;

import org.junit.Test;

import cs3500.threetrios.model.Color;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Tests for the ModelFeatures interface.
 */
public class TestModelFeatures extends TestThreeTriosGameController {

  @Test
  public void testRefreshGameStateWorks() {
    ThreeTriosGameController controller = new ThreeTriosGameController(realModel,
            mockPlayer1, mockView, Color.RED);
    realModel.startGame();
    controller.selectCard(0, Color.RED);
    controller.selectCell(0, 0);
    assertTrue(log.toString().contains("refreshGameState called"));
  }

  @Test
  public void testPlayTurnWorks() {
    ThreeTriosGameController controller = new ThreeTriosGameController(realModel,
            mockPlayer1, mockView, Color.RED);

    realModel.startGame();
    controller.playTurn(Color.BLUE);
    controller.playTurn(Color.BLUE);
    // make sure it calls the makeMove method in the machine player
    assertTrue(log.toString().contains("makeMove called\n"));
  }

  @Test
  public void testPlayTurnWithPlayerColorNull() {
    ThreeTriosGameController controller = new ThreeTriosGameController(mockModel,
            mockPlayer1, mockView, Color.RED);
    controller.playTurn(null);
    assertEquals("addFeatures called\n"
            + "addFeatures called\n"
            + "showMessage called with message='Unable to recognize player'\n", log.toString());
  }
}
