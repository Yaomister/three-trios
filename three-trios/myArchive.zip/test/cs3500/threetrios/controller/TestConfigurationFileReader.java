package cs3500.threetrios.controller;

import org.junit.Test;

import java.util.List;

import cs3500.threetrios.model.AttackValue;
import cs3500.threetrios.model.Card;
import cs3500.threetrios.model.GameCard;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

/**
 * Test class for ConfigurationFileReader
 * These tests ensure that the ConfigurationFileReader class throws the correct exceptions
 * and returns the correct grid and deck.
 */
public class TestConfigurationFileReader {

  private final String nonExistingFile = "NonExistingFile.txt";

  @Test(expected = IllegalArgumentException.class)
  public void testCreatingGridFromNonExistingFileNameThrowsIAE() {
    ConfigurationFileReader.createGridFromFile(nonExistingFile);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreatingDeckFromNonExistingFileNameThrowsIAE() {
    ConfigurationFileReader.createGridFromFile(nonExistingFile);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreatingGridFromNullFileNameThrowsIAE() {
    ConfigurationFileReader.createGridFromFile(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreatingDeckFromNullFileThrowsIAE() {
    ConfigurationFileReader.createGridFromFile(null);
  }


  @Test
  public void testCreatingDeckFromFileWorks() {
    List<Card> deck = ConfigurationFileReader.createDeckFromFile("deckSmall.txt");
    assertEquals(3, deck.size());
    assertEquals(new GameCard("SurgeTheSodaMachine",
            AttackValue.SEVEN, AttackValue.FOUR, AttackValue.THREE, AttackValue.A), deck.get(0));
    assertEquals(new GameCard("RtTheCopRobot", AttackValue.EIGHT,
            AttackValue.A, AttackValue.TWO, AttackValue.FIVE), deck.get(1));
    assertEquals(new GameCard("JanetTheFlyingStar", AttackValue.FOUR,
            AttackValue.FOUR, AttackValue.FOUR, AttackValue.FOUR), deck.get(2));
  }

  @Test
  public void testCreatingGridFromFileWorks() {
    boolean[][] gridWithoutHoles = ConfigurationFileReader
            .createGridFromFile("gridWithNoHoles.txt");
    boolean[][] gridWithHoles = ConfigurationFileReader
            .createGridFromFile("docs/gridWithPathToAllCells.txt");

    boolean[][] expectedGridWithoutHoles = {
            {false, false, false},
            {false, false, false},
            {false, false, false},
    };
    boolean[][] expectedGridWithHoles = {
            {false, true, false, true, false},
            {false, false, false, false, false},
            {false, true, false, true, false},
            {false, false, false, false, false},
            {false, true, false, true, false},
    };


    assertArrayEquals(expectedGridWithoutHoles, gridWithoutHoles);
    assertArrayEquals(expectedGridWithHoles, gridWithHoles);
  }

  @Test
  public void testReadingInDeckByGivingFileNameAndFileDirectoryProducesSameDeck() {
    List<Card> deckByFileName = ConfigurationFileReader
            .createDeckFromFile("deckSmall.txt");
    List<Card> deckByFileDirectory = ConfigurationFileReader
            .createDeckFromFile("docs/deckSmall.txt");
    assertEquals(deckByFileName, deckByFileDirectory);
  }

  @Test
  public void testReadingInGridByGivingFileNameAndFileDirectoryProducesSameGrid() {
    boolean[][] gridByFileName = ConfigurationFileReader
            .createGridFromFile("gridWithNoHoles.txt");
    boolean[][] gridByFileDirectory = ConfigurationFileReader
            .createGridFromFile("docs/gridWithNoHoles.txt");
    assertArrayEquals(gridByFileDirectory, gridByFileName);
  }

  @Test
  public void testCreatingGridFromVariousFileTypesWorks() {
    boolean[][] gridFromConfigFile = ConfigurationFileReader
            .createGridFromFile("gridWithNoHoles.config");
    boolean[][] gridFromTextFile = ConfigurationFileReader
            .createGridFromFile("gridWithNoHoles.txt");
    assertArrayEquals(gridFromConfigFile, gridFromTextFile);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreatingDeckWithFileIncorrectlyFormattedThrowsIAE() {
    ConfigurationFileReader.createDeckFromFile("deckIncorrectFormat.txt");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreatingGridWithEvenPlayableCellsThrowIAE() {
    ConfigurationFileReader.createGridFromFile("gridWithEvenPlayableCells.txt");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreatingGridWithFileIncorrectlyFormattedThrowIAE() {
    ConfigurationFileReader.createGridFromFile("gridIncorrectFormat.txt");
  }


}
