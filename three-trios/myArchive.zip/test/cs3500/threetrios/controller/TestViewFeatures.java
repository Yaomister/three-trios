package cs3500.threetrios.controller;

import org.junit.Test;

import cs3500.threetrios.MockPlayerConfirmsMethodCalls;
import cs3500.threetrios.model.Color;
import cs3500.threetrios.players.MachinePlayer;
import cs3500.threetrios.players.Player;
import cs3500.threetrios.strategies.MaximizeFlipsStrategy;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Tests for the ViewFeatures interface.
 */
public class TestViewFeatures extends TestThreeTriosGameController {

  @Test
  public void testSelectCardWorks() {

    ViewFeatures controller = new ThreeTriosGameController(mockModel,
            mockPlayer1, mockView, Color.RED);

    controller.selectCard(0, Color.RED);
    assertEquals("addFeatures called\n"
                    + "addFeatures called\n"
                    + "getCurrentPlayerColor called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n",
            log.toString());
  }

  @Test
  public void testSelectCellWorks() {

    ViewFeatures controller = new ThreeTriosGameController(mockModel,
            mockPlayer1, mockView, Color.RED);

    controller.selectCard(0, Color.RED);
    controller.selectCell(1, 1);
    assertEquals("addFeatures called\n"
                    + "addFeatures called\n"
                    + "getCurrentPlayerColor called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "getCurrentPlayerColor called\n"
                    + "playCard called with row=1, col=1, cardIndex=0\n"
                    + "deselectCard called\n"
                    + "battle called\n"
                    + "isGameOver called\n",

            log.toString());
  }

  @Test
  public void testControllerPreventsSelectingOpponentsCard() {

    ThreeTriosGameController controller = new ThreeTriosGameController(mockModel,
            mockPlayer1, mockView, Color.RED);

    controller.selectCard(1, Color.BLUE);
    assertEquals("addFeatures called\n"
                    + "addFeatures called\n"
                    + "getCurrentPlayerColor called\n"
                    + "showMessage called with message='Player RED: "
                    + "Cannot select opponents cards'\n",
            log.toString());
  }

  @Test
  public void testControllerEnsuresCardIsSelectedBeforePlaying() {

    ThreeTriosGameController controller = new ThreeTriosGameController(mockModel,
            mockPlayer1, mockView, Color.RED);

    controller.selectCell(0, 0);
    assertEquals("addFeatures called\n"
                    + "addFeatures called\n"
                    + "getCurrentPlayerColor called\n"
                    + "showMessage called with message='Player RED: Please select a card first'\n",
            log.toString());
  }

  @Test
  public void testPlayerCanOnlyTakeActionDuringTheirTurn() {
    ThreeTriosGameController controller = new ThreeTriosGameController(mockModel,
            mockPlayer1, mockView, Color.BLUE);
    mockPlayer1.makeMove();
    assertEquals("addFeatures called\n"
                    + "addFeatures called\n"
                    + "makeMove called\n"
                    + "getCurrentPlayerColor called\n"
                    + "showMessage called with message='Player BLUE: Please wait until your turn'\n"
                    + "getCurrentPlayerColor called\n"
                    + "showMessage called with message='Player BLUE: "
                    + "Please wait until your turn'\n",
            log.toString());

  }

  @Test
  public void testControllerTellsViewToDisplayWinningMessage() {
    Player machine1 = new MachinePlayer(realModel,
            new MaximizeFlipsStrategy(null), Color.RED);
    Player machine2 = new MachinePlayer(realModel,
            new MaximizeFlipsStrategy(null), Color.BLUE);
    new ThreeTriosGameController(realModel,
            machine1, mockView, Color.RED);
    new ThreeTriosGameController(realModel,
            machine2, mockView, Color.BLUE);
    realModel.startGame();
    assertTrue(log.toString().contains("showMessage called with message="
            + "'Player BLUE won! The winning score is 14'\n"));
  }

  @Test
  public void testSelectCardDeselectsCard() {
    ThreeTriosGameController controller = new ThreeTriosGameController(realModel,
            mockPlayer1, mockView, Color.RED);
    realModel.startGame();

    controller.selectCard(0, Color.RED);
    controller.selectCard(0, Color.RED);
    assertTrue(log.toString().contains("highlightCard called with cardIndex=0, color=RED\n"
            + "deselectCard called\n"));
  }

  @Test
  public void testSelectCellWithInvalidIndexes() {
    ThreeTriosGameController controller = new ThreeTriosGameController(realModel,
            new MockPlayerConfirmsMethodCalls(log), mockView, Color.RED);
    realModel.startGame();

    controller.selectCard(0, Color.RED);
    controller.selectCell(-1, -1);

    assertEquals("addFeatures called\n"
                    + "makeMove called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "showMessage called with message='Player RED: Column index out of bounds.'\n",
            log.toString());
  }

  @Test
  public void testSelectCardWithPlayerColorNull() {
    ThreeTriosGameController controller = new ThreeTriosGameController(mockModel,
            mockPlayer1, mockView, Color.RED);
    controller.selectCard(0, null);
    assertEquals("addFeatures called\n"
            + "addFeatures called\n"
            + "showMessage called with message='Unrecognizable card color!'\n", log.toString());
  }
}
