package cs3500.threetrios.controller;

import cs3500.threetrios.MockPlayer;
import cs3500.threetrios.MockThreeTriosFrame;
import cs3500.threetrios.MockThreeTriosModelForControllerOver;
import cs3500.threetrios.model.Color;
import cs3500.threetrios.model.ThreeTriosGameModel;
import cs3500.threetrios.model.ThreeTriosModel;
import cs3500.threetrios.players.HumanPlayer;
import cs3500.threetrios.players.MachinePlayer;
import cs3500.threetrios.players.Player;
import cs3500.threetrios.strategies.MaximizeFlipsStrategy;
import cs3500.threetrios.view.ThreeTriosFrame;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Tests for the ThreeTriosGameController class.
 */
public class TestThreeTriosGameController {

  protected ThreeTriosModel mockModel;
  protected ThreeTriosFrame mockView;
  protected Player mockPlayer1;
  protected ThreeTriosModel realModel;
  protected StringBuilder log;

  @Before
  public void setup() {
    this.log = new StringBuilder();
    this.mockModel = new MockThreeTriosModelForControllerOver(log);
    this.mockView = new MockThreeTriosFrame(log);
    this.mockPlayer1 = new MockPlayer(log);
    this.realModel = new ThreeTriosGameModel(ConfigurationFileReader
            .createGridFromFile("gridClassExample.txt"),
            ConfigurationFileReader.createDeckFromFile("deckLarge.txt"));
  }

  @Test
  public void testControllerIsRegisteredAsListenerForModelAndPlayer() {
    new ThreeTriosGameController(mockModel, mockPlayer1, mockView, Color.RED);
    assertEquals("addFeatures called\naddFeatures called\n", log.toString());
  }


  @Test(expected = IllegalArgumentException.class)
  public void testNullView() {
    new ThreeTriosGameController(mockModel, mockPlayer1, null, Color.RED);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullModel() {
    new ThreeTriosGameController(null, mockPlayer1, mockView, Color.RED);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullPlayer() {
    new ThreeTriosGameController(mockModel, null, mockView, Color.RED);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullColor() {
    new ThreeTriosGameController(mockModel, mockPlayer1, mockView, null);
  }

  @Test
  public void testHumanAndMachinePlayTillEnd() {
    Player human1 = new HumanPlayer();
    Player machine2 = new MachinePlayer(realModel,
            new MaximizeFlipsStrategy(null), Color.BLUE);
    ThreeTriosGameController controller = new ThreeTriosGameController(realModel,
            human1, mockView, Color.RED);
    new ThreeTriosGameController(realModel,
            machine2, mockView, Color.BLUE);
    realModel.startGame();
    controller.selectCard(0, Color.RED);
    controller.selectCell(0, 0);
    controller.selectCard(0, Color.RED);
    controller.selectCell(1, 0);
    controller.selectCard(0, Color.RED);
    controller.selectCell(3, 0);
    controller.selectCard(0, Color.RED);
    controller.selectCell(1, 2);
    controller.selectCard(0, Color.RED);
    controller.selectCell(2, 3);
    controller.selectCard(0, Color.RED);
    controller.selectCell(3, 4);
    controller.selectCard(0, Color.RED);
    controller.selectCell(4, 6);
    controller.selectCard(0, Color.RED);
    controller.selectCell(3, 6);

    assertEquals("addFeatures called\n"
                    + "addFeatures called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=1, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "showMessage called with message='Player BLUE won! The winning score is 10'\n"
                    + "refreshGameState called\n"
                    + "showMessage called with message='Player BLUE won!"
                    + " The winning score is 10'\n",
            log.toString());
  }

  @Test
  public void testMachineAndMachinePlayTillEnd() {
    Player machine1 = new MachinePlayer(realModel, new MaximizeFlipsStrategy(null), Color.RED);
    Player machine2 = new MachinePlayer(realModel, new MaximizeFlipsStrategy(null), Color.BLUE);
    new ThreeTriosGameController(realModel,
            machine1, mockView, Color.RED);
    new ThreeTriosGameController(realModel,
            machine2, mockView, Color.BLUE);
    realModel.startGame();
    assertEquals("addFeatures called\n"
                    + "addFeatures called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=1, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=3, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=1, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "showMessage called with message='Player BLUE won! The winning score is 14'\n"
                    + "refreshGameState called\n"
                    + "showMessage called with message='Player BLUE won! "
                    + "The winning score is 14'\n",
            log.toString());
  }

  @Test
  public void testHumanAndHumanPlayTillEnd() {
    Player human1 = new HumanPlayer();
    Player human2 = new HumanPlayer();
    ThreeTriosGameController controller1 = new ThreeTriosGameController(realModel,
            human1, mockView, Color.RED);
    ThreeTriosGameController controller2 = new ThreeTriosGameController(realModel,
            human2, mockView, Color.BLUE);
    realModel.startGame();
    controller1.selectCard(0, Color.RED);
    controller1.selectCell(0, 0);

    controller2.selectCard(0, Color.BLUE);
    controller2.selectCard(0, Color.BLUE);
    controller2.selectCard(1, Color.BLUE);
    controller2.selectCell(0, 1);
    controller1.selectCard(0, Color.RED);
    controller1.selectCell(1, 0);
    controller2.selectCard(0, Color.BLUE);
    controller2.selectCell(2, 0);
    controller1.selectCard(0, Color.RED);
    controller1.selectCell(3, 0);
    controller2.selectCard(0, Color.BLUE);
    controller2.selectCell(4, 0);
    controller1.selectCard(0, Color.RED);
    controller1.selectCell(1, 2);
    controller2.selectCard(0, Color.BLUE);
    controller2.selectCell(2, 3);
    controller1.selectCard(0, Color.RED);
    controller1.selectCell(3, 4);
    controller2.selectCard(0, Color.BLUE);
    controller2.selectCell(4, 5);
    controller1.selectCard(0, Color.RED);
    controller1.selectCell(0, 6);
    controller2.selectCard(0, Color.BLUE);
    controller2.selectCell(1, 6);
    controller1.selectCard(0, Color.RED);
    controller1.selectCell(2, 6);
    controller2.selectCard(0, Color.BLUE);
    controller2.selectCell(3, 6);
    controller1.selectCard(0, Color.RED);
    controller1.selectCell(4, 6);
    assertEquals("addFeatures called\n"
                    + "addFeatures called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=BLUE\n"
                    + "deselectCard called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=1, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=BLUE\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "refreshGameState called\n"
                    + "deselectCard called\n"
                    + "highlightCard called with cardIndex=0, color=RED\n"
                    + "deselectCard called\n"
                    + "refreshGameState called\n"
                    + "showMessage called with message='There is a tie!'\n"
                    + "refreshGameState called\n"
                    + "showMessage called with message='There is a tie!'\n",
            log.toString());
  }
}
