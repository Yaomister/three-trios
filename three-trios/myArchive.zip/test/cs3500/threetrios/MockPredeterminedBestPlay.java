package cs3500.threetrios;

import java.util.List;

import cs3500.threetrios.model.Card;

/**
 * Mock class for testing model knows there is a best move to make.
 */
public class MockPredeterminedBestPlay extends Mock {

  public MockPredeterminedBestPlay(boolean[][] grid, List<Card> deck) {
    super(grid, deck);
  }

  // make (1, 1) the move we want to see
  @Override
  public int amountOfCardsFlippedByPlayingAt(Card card, int row, int col) {
    if (row == 1 && col == 1) {
      return 100;
    }
    return 1;
  }
}
