package cs3500.threetrios;

import java.util.List;

import cs3500.threetrios.model.Card;

/**
 * Mock class to test that the game is over and ended.
 */
public class MockGameOver extends Mock {
  public MockGameOver(boolean[][] grid, List<Card> deck) {
    super(grid, deck);
  }

  @Override
  public boolean isGameOver() {
    return true;
  }
}
