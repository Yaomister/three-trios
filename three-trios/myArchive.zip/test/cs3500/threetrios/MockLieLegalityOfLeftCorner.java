package cs3500.threetrios;

import java.util.List;

import cs3500.threetrios.model.Card;

/**
 * Mock class to test the legality of the left corner.
 */
public class MockLieLegalityOfLeftCorner extends Mock {

  public MockLieLegalityOfLeftCorner(boolean[][] grid, List<Card> deck) {
    super(grid, deck);
  }

  @Override
  public boolean isPlayLegal(int row, int col) {
    // make top left corner unavailable
    return row >= 1 || col >= 1;
  }
}
