package cs3500.threetrios.player;

import org.junit.Before;
import org.junit.Test;

import cs3500.threetrios.MockPlayer;
import cs3500.threetrios.MockThreeTriosFrame;
import cs3500.threetrios.MockThreeTriosModelForControllerActive;
import cs3500.threetrios.controller.ConfigurationFileReader;
import cs3500.threetrios.controller.ThreeTriosGameController;
import cs3500.threetrios.model.Color;
import cs3500.threetrios.model.ThreeTriosGameModel;
import cs3500.threetrios.model.ThreeTriosModel;
import cs3500.threetrios.players.MachinePlayer;
import cs3500.threetrios.players.Player;
import cs3500.threetrios.strategies.MaximizeFlipsStrategy;
import cs3500.threetrios.view.ThreeTriosFrame;

import static org.junit.Assert.assertTrue;

/**
 * Tests for the Player class.
 * This class tests the Player class and its subclasses.
 */
public class TestPlayer {

  protected ThreeTriosModel mockModel;
  protected ThreeTriosFrame mockView;
  protected Player mockPlayer1;
  protected ThreeTriosModel realModel;
  protected StringBuilder log;

  @Before
  public void setup() {
    this.log = new StringBuilder();
    this.mockModel = new MockThreeTriosModelForControllerActive(log);
    this.mockView = new MockThreeTriosFrame(log);
    this.mockPlayer1 = new MockPlayer(log);
    this.realModel = new ThreeTriosGameModel(ConfigurationFileReader
            .createGridFromFile("gridClassExample.txt"),
            ConfigurationFileReader.createDeckFromFile("deckLarge.txt"));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMachinePlayerConstructionWithNullModelThrowsIAE() {
    new MachinePlayer(null, new MaximizeFlipsStrategy(null), Color.RED);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMachinePlayerConstructionWithNullStrateyThrowsIAE() {
    new MachinePlayer(realModel, null, Color.RED);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMachinePlayerConstructionWithNullColorThrowsIAE() {
    new MachinePlayer(realModel, new MaximizeFlipsStrategy(null), null);
  }

  @Test
  public void testMakeMoveWorks() {
    Player player = new MachinePlayer(mockModel, new MaximizeFlipsStrategy(null), Color.RED);
    ThreeTriosGameController controller = new ThreeTriosGameController(mockModel,
            player, mockView, Color.RED);
    player.makeMove();
    assertTrue(log.toString().contains("highlightCard called with cardIndex=0, color=RED"));
    assertTrue(log.toString().contains("playCard called with row=0, col=0, cardIndex=0"));
    assertTrue(log.toString().contains("battle called"));
    assertTrue(log.toString().contains("isGameOver called"));
    assertTrue(log.toString().contains("nextTurn called"));

  }
}
