package cs3500.threetrios;

import java.util.ArrayList;
import java.util.List;

import cs3500.threetrios.controller.ModelFeatures;
import cs3500.threetrios.model.Card;
import cs3500.threetrios.model.Cell;
import cs3500.threetrios.model.GameCell;
import cs3500.threetrios.model.Color;
import cs3500.threetrios.model.Phase;
import cs3500.threetrios.model.ThreeTriosModel;

/**
 * Mock class for testing the ThreeTriosModel.
 */
public class Mock implements ThreeTriosModel {

  private final List<Card> mockHand;

  public Mock(boolean[][] grid, List<Card> deck) {
    this.mockHand = deck.subList(0, 5);
  }

  @Override
  public boolean isGameOver() {
    return false;
  }

  @Override
  public Color getWinner() {
    return null;
  }

  @Override
  public Phase getPhase() {
    return null;
  }

  @Override
  public GameCell getCellAt(int row, int col) {
    return null;
  }

  @Override
  public int amountOfCardsFlippedByPlayingAt(Card card, int row, int col) {
    return 0;
  }

  @Override
  public List<Card> getPlayerHand(Color player) {
    return new ArrayList<>(this.mockHand);
  }

  @Override
  public int getGridWidth() {
    return 3;
  }

  @Override
  public int getGridHeight() {
    return 3;
  }

  @Override
  public Color getCurrentPlayerColor() {
    return Color.RED;
  }

  @Override
  public boolean isPlayLegal(int row, int col) {
    return true;
  }

  @Override
  public int getPlayerScore(Color playerColor) {
    return 0;
  }

  @Override
  public Cell[][] getGrid() {
    Cell[][] grid = new Cell[3][3];
    for (int row = 0; row < 3; row++) {
      for (int col = 0; col < 3; col++) {
        grid[row][col] = new GameCell(null);
        grid[row][col].setHole(false);
      }
    }
    return grid;
  }

  @Override
  public void playCard(int cellIndexRow, int cellIndexCol, int cardIndexInHand) {
    // No need to implement for mocks.
  }

  @Override
  public void startGame() {
    // No need to implement for mocks;
  }

  @Override
  public void nextTurn() {
    // No need to implement for mocks.

  }

  @Override
  public void battle() {
    // No need to implement for mocks.
  }

  @Override
  public void addFeatures(ModelFeatures features) {
    // No need to implement for mocks.
  }
}
