package cs3500.threetrios;

import java.util.List;

import cs3500.threetrios.model.Card;

/**
 * A mock class for testing the CannotPlayAnywhere exception.
 */
public class MockCannotPlayAnywhere extends Mock {
  public MockCannotPlayAnywhere(boolean[][] grid, List<Card> deck) {
    super(grid, deck);
  }

  @Override
  public boolean isPlayLegal(int row, int col) {
    return false;
  }
}
