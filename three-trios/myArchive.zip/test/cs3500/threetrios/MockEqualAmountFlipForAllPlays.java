package cs3500.threetrios;

import java.util.List;

import cs3500.threetrios.model.Card;

/**
 * Mock Class to test equal amounts of card flips.
 */
public class MockEqualAmountFlipForAllPlays extends Mock {

  public MockEqualAmountFlipForAllPlays(boolean[][] grid, List<Card> deck) {
    super(grid, deck);
  }

  @Override
  public int amountOfCardsFlippedByPlayingAt(Card card, int row, int col) {
    return 10;
  }

}
