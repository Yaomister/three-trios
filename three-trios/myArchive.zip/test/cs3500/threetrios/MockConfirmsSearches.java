package cs3500.threetrios;

import java.io.IOException;
import java.util.List;
import java.util.Objects;

import cs3500.threetrios.model.Card;

/**
 * A mock model for testing confirm searches.
 */
public class MockConfirmsSearches extends Mock {

  // Represents a model with a 3 x 3 grid with no holes.
  private final Appendable out;

  /**
   * Constructs a mock model for testing confirm searches.
   */
  public MockConfirmsSearches(boolean[][] grid, List<Card> deck, Appendable log) {
    super(grid, deck);
    this.out = Objects.requireNonNull(log);
  }

  protected void log(String message) {
    try {
      this.out.append(message);
    } catch (IOException ignored) {

    }
  }

  @Override
  public int amountOfCardsFlippedByPlayingAt(Card card, int row, int col) {
    this.log("Calculated damage for placing " + card.getName()
            + " at (" + row + "," + col + ")" + System.lineSeparator());
    return 0;
  }

  @Override
  public boolean isPlayLegal(int row, int col) {
    this.log("Inspected legality of playing at (" + row + "," + col + ")" + System.lineSeparator());
    return true;
  }

}
