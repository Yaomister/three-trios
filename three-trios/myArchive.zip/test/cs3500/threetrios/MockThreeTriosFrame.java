package cs3500.threetrios;

import cs3500.threetrios.controller.ViewFeatures;
import cs3500.threetrios.model.Color;
import cs3500.threetrios.view.ThreeTriosFrame;

/**
 * Mock class for testing the ThreeTriosFrame.
 */
public class MockThreeTriosFrame implements ThreeTriosFrame {
  private final StringBuilder log;

  public MockThreeTriosFrame(StringBuilder log) {
    this.log = log;
  }

  @Override
  public void addFeatures(ViewFeatures features) {
    log.append("addFeatures called\n");
  }

  @Override
  public void deselectCard() {
    log.append("deselectCard called\n");
  }

  @Override
  public void highlightCard(int cardIndex, Color color) {
    log.append("highlightCard called with cardIndex=").append(cardIndex)
            .append(", color=").append(color).append("\n");
  }

  @Override
  public void showMessage(String message) {
    log.append("showMessage called with message='").append(message).append("'\n");
  }

  @Override
  public void refreshGameState() {
    log.append("refreshGameState called\n");
  }

  @Override
  public void showTitle(String title) {
    // Method does not need to be implemented
  }
}
