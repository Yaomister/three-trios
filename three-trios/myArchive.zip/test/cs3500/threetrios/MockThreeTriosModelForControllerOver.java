package cs3500.threetrios;

import cs3500.threetrios.controller.ModelFeatures;
import cs3500.threetrios.model.AttackValue;
import cs3500.threetrios.model.Card;
import cs3500.threetrios.model.Cell;
import cs3500.threetrios.model.Color;
import cs3500.threetrios.model.GameCard;
import cs3500.threetrios.model.GameCell;
import cs3500.threetrios.model.Phase;
import cs3500.threetrios.model.ThreeTriosModel;

import java.util.List;

/**
 * Mock implementation of the ThreeTriosModel interface for testing purposes.
 */
public class MockThreeTriosModelForControllerOver implements ThreeTriosModel {
  protected final StringBuilder log;

  /**
   * Constructs a new MockThreeTriosModelForController with the given StringBuilder.
   *
   * @param log the log to which logs will be appended
   */
  public MockThreeTriosModelForControllerOver(StringBuilder log) {
    this.log = log;
  }

  @Override
  public void playCard(int row, int col, int cardIndex) {
    log.append("playCard called with row=").append(row).append(", col=").append(col)
            .append(", cardIndex=").append(cardIndex).append("\n");
  }

  @Override
  public void startGame() {
    // Method does not need to be implemented
  }

  @Override
  public void nextTurn() {
    log.append("nextTurn called\n");
  }

  @Override
  public void battle() {
    log.append("battle called\n");
  }

  @Override
  public void addFeatures(ModelFeatures features) {
    log.append("addFeatures called\n");
  }

  @Override
  public Color getCurrentPlayerColor() {
    log.append("getCurrentPlayerColor called\n");
    return Color.RED;
  }

  @Override
  public boolean isPlayLegal(int row, int col) {
    return true;
  }

  @Override
  public int getGridWidth() {
    return 4;
  }

  @Override
  public int getGridHeight() {
    return 4;
  }

  @Override
  public boolean isGameOver() {
    log.append("isGameOver called\n");
    return true;
  }

  @Override
  public Color getWinner() {
    log.append("getWinner called\n");
    return Color.RED;
  }

  @Override
  public Phase getPhase() {
    return null;
  }

  @Override
  public Cell getCellAt(int row, int col) {
    return new GameCell(null);
  }

  @Override
  public int amountOfCardsFlippedByPlayingAt(Card card, int row, int col) {
    return 1;
  }

  @Override
  public List<Card> getPlayerHand(Color player) {
    return List.of(new GameCard("Test Card", AttackValue.A, AttackValue.A,
            AttackValue.A, AttackValue.A));
  }

  @Override
  public int getPlayerScore(Color color) {
    log.append("getPlayerScore called with color=").append(color).append("\n");
    return 10;
  }

  @Override
  public Cell[][] getGrid() {
    return new Cell[0][];
  }


}
