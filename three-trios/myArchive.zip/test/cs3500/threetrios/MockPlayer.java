package cs3500.threetrios;

import cs3500.threetrios.controller.ViewFeatures;
import cs3500.threetrios.model.Color;
import cs3500.threetrios.players.Player;

/**
 * A mock implementation of the Player interface for testing purposes.
 */
public class MockPlayer implements Player {

  private ViewFeatures features;

  protected final StringBuilder log;

  /**
   * Constructor for the MockPlayerAction class.
   *
   * @param log The StringBuilder to which logs will be appended.
   */
  public MockPlayer(StringBuilder log) {
    this.log = log;
  }

  @Override
  public void makeMove() {
    log.append("makeMove called").append(System.lineSeparator());
    this.features.selectCard(0, Color.RED);
    this.features.selectCell(0, 0);
  }

  @Override
  public void addFeatures(ViewFeatures features) {
    this.features = features;
  }
}
