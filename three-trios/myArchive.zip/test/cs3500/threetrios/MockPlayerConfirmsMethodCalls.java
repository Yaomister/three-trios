package cs3500.threetrios;

import cs3500.threetrios.controller.ViewFeatures;

/**
 * Mock Player that confirms that the method calls are made.
 */
public class MockPlayerConfirmsMethodCalls extends MockPlayer {


  private ViewFeatures features;


  /**
   * Constructor for the MockPlayerAction class.
   *
   * @param log The StringBuilder to which logs will be appended.
   */
  public MockPlayerConfirmsMethodCalls(StringBuilder log) {
    super(log);
  }

  @Override
  public void makeMove() {
    log.append("makeMove called").append(System.lineSeparator());
  }

}
